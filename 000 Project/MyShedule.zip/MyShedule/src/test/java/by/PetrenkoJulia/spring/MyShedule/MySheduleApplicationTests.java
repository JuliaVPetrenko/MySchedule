package by.PetrenkoJulia.spring.MyShedule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySheduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
