package by.PetrenkoJulia.spring.MyShedule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySheduleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySheduleApplication.class, args);
	}

}
